ResearchVault - Research Paper and Reference Management System

How to run in Eclipse:
1. Open Eclipse.
2. File > Import > General > Existing Projects into Workspace.
3. Select the unzipped ResearchVault folder.
4. Open src/Main.java.
5. Click Run.
6. Choose 1 for GUI or 2 for Text-Based Interface.

JUnit test setup:
1. Right-click project > Build Path > Add Libraries.
2. Select JUnit > JUnit 5.
3. Right-click test/PaperManagerTest.java > Run As > JUnit Test.

Features:
- Add research paper
- Delete research paper
- View papers
- Search papers using linear search
- Sort papers using merge sort
- GUI using Java Swing
- Text-Based Interface using Scanner
- Save/load using CSV file
- JUnit tests for add, search, and delete
