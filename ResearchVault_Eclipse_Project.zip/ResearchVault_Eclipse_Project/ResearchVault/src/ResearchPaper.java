import java.util.Objects;

public class ResearchPaper {
    private String title;
    private String author;
    private int year;
    private String topic;
    private String status;

    public ResearchPaper(String title, String author, int year, String topic, String status) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.topic = topic;
        this.status = status;
    }

    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getYear() { return year; }
    public String getTopic() { return topic; }
    public String getStatus() { return status; }

    public void setTitle(String title) { this.title = title; }
    public void setAuthor(String author) { this.author = author; }
    public void setYear(int year) { this.year = year; }
    public void setTopic(String topic) { this.topic = topic; }
    public void setStatus(String status) { this.status = status; }

    public String toCsv() {
        return escape(title) + "," + escape(author) + "," + year + "," + escape(topic) + "," + escape(status);
    }

    public static ResearchPaper fromCsv(String line) {
        String[] parts = line.split(",", -1);
        if (parts.length != 5) return null;
        try {
            return new ResearchPaper(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3], parts[4]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String escape(String value) {
        if (value == null) return "";
        return value.replace(",", " ").trim();
    }

    @Override
    public String toString() {
        return title + " | " + author + " | " + year + " | " + topic + " | " + status;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof ResearchPaper)) return false;
        ResearchPaper other = (ResearchPaper) obj;
        return year == other.year && Objects.equals(title, other.title) && Objects.equals(author, other.author)
                && Objects.equals(topic, other.topic) && Objects.equals(status, other.status);
    }
}
