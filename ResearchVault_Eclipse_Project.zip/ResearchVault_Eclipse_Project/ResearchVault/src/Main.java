import javax.swing.SwingUtilities;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        PaperManager manager = new PaperManager();
        Scanner scanner = new Scanner(System.in);

        System.out.println("===== ResearchVault =====");
        System.out.println("1. Graphical User Interface (GUI)");
        System.out.println("2. Text-Based Interface (TBI)");
        System.out.print("Choose mode: ");

        String choice = scanner.nextLine();

        if (choice.equals("1")) {
            SwingUtilities.invokeLater(() -> new ResearchVaultGUI().setVisible(true));
        } else if (choice.equals("2")) {
            new ResearchVaultTBI(manager).start();
        } else {
            System.out.println("Invalid choice. Program closed.");
        }

        scanner.close();
    }
}