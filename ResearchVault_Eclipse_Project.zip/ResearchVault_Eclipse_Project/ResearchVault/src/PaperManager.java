import java.io.*;
import java.util.*;

public class PaperManager {
    private ArrayList<ResearchPaper> papers = new ArrayList<>();

    public void addPaper(ResearchPaper paper) {
        if (paper != null) papers.add(paper);
    }

    public boolean deletePaperByTitle(String title) {
        for (int i = 0; i < papers.size(); i++) {
            if (papers.get(i).getTitle().equalsIgnoreCase(title)) {
                papers.remove(i);
                return true;
            }
        }
        return false;
    }

    public ArrayList<ResearchPaper> getAllPapers() {
        return papers;
    }
    // Linear Search: O(n)
    public ArrayList<ResearchPaper> search(String keyword) {
        ArrayList<ResearchPaper> result = new ArrayList<>();
        if (keyword == null) return result;
        String key = keyword.toLowerCase();
        for (ResearchPaper paper : papers) {
            if (paper.getTitle().toLowerCase().contains(key)
                    || paper.getAuthor().toLowerCase().contains(key)
                    || paper.getTopic().toLowerCase().contains(key)
                    || String.valueOf(paper.getYear()).contains(key)
                    || paper.getStatus().toLowerCase().contains(key)) {
                result.add(paper);
            }
        }
        return result;
    }

    public void sortByTitle() {
        mergeSort(Comparator.comparing(ResearchPaper::getTitle, String.CASE_INSENSITIVE_ORDER));
    }

    public void sortByAuthor() {
        mergeSort(Comparator.comparing(ResearchPaper::getAuthor, String.CASE_INSENSITIVE_ORDER));
    }

    public void sortByYear() {
        mergeSort(Comparator.comparingInt(ResearchPaper::getYear));
    }

    // Merge Sort: O(n log n)
    private void mergeSort(Comparator<ResearchPaper> comparator) {
        papers = mergeSortList(papers, comparator);
    }

    private ArrayList<ResearchPaper> mergeSortList(ArrayList<ResearchPaper> list, Comparator<ResearchPaper> comparator) {
        if (list.size() <= 1) return list;
        int mid = list.size() / 2;
        ArrayList<ResearchPaper> left = new ArrayList<>(list.subList(0, mid));
        ArrayList<ResearchPaper> right = new ArrayList<>(list.subList(mid, list.size()));
        return merge(mergeSortList(left, comparator), mergeSortList(right, comparator), comparator);
    }

    private ArrayList<ResearchPaper> merge(ArrayList<ResearchPaper> left, ArrayList<ResearchPaper> right, Comparator<ResearchPaper> comparator) {
        ArrayList<ResearchPaper> merged = new ArrayList<>();
        int i = 0, j = 0;
        while (i < left.size() && j < right.size()) {
            if (comparator.compare(left.get(i), right.get(j)) <= 0) merged.add(left.get(i++));
            else merged.add(right.get(j++));
        }
        while (i < left.size()) merged.add(left.get(i++));
        while (j < right.size()) merged.add(right.get(j++));
        return merged;
    }

    public void saveToFile(String filename) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (ResearchPaper paper : papers) writer.println(paper.toCsv());
        }
    }

    public void loadFromFile(String filename) throws IOException {
        papers.clear();
        File file = new File(filename);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                ResearchPaper paper = ResearchPaper.fromCsv(line);
                if (paper != null) papers.add(paper);
            }
        }
    }
}
