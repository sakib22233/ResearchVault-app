import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.Comparator;

public class ResearchVaultGUI extends JFrame {

    private PaperManager manager = new PaperManager();

    private JTextField titleField, authorField, yearField, topicField, searchField;
    private JComboBox<String> statusBox, sortBox, filterBox;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel countLabel;

    public ResearchVaultGUI() {
        setTitle("ResearchVault - Research Paper Organizer");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel titleBanner = new JLabel("ResearchVault - Research Paper Management System", JLabel.CENTER);
        titleBanner.setFont(new Font("Arial", Font.BOLD, 24));
        titleBanner.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        add(titleBanner, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(7, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder("Paper Details"));

        titleField = new JTextField();
        authorField = new JTextField();
        yearField = new JTextField();
        topicField = new JTextField();
        statusBox = new JComboBox<>(new String[]{"Not Started", "Reading", "Completed"});

        JButton addButton = new JButton("Add Paper");
        JButton updateButton = new JButton("Update Selected");
        JButton clearButton = new JButton("Clear Fields");

        formPanel.add(new JLabel("Title:"));
        formPanel.add(titleField);
        formPanel.add(new JLabel("Author:"));
        formPanel.add(authorField);
        formPanel.add(new JLabel("Year:"));
        formPanel.add(yearField);
        formPanel.add(new JLabel("Topic:"));
        formPanel.add(topicField);
        formPanel.add(new JLabel("Reading Status:"));
        formPanel.add(statusBox);
        formPanel.add(addButton);
        formPanel.add(updateButton);
        formPanel.add(clearButton);

        add(formPanel, BorderLayout.WEST);

        tableModel = new DefaultTableModel(new String[]{"Title", "Author", "Year", "Topic", "Status"}, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(25);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                titleField.setText(tableModel.getValueAt(row, 0).toString());
                authorField.setText(tableModel.getValueAt(row, 1).toString());
                yearField.setText(tableModel.getValueAt(row, 2).toString());
                topicField.setText(tableModel.getValueAt(row, 3).toString());
                statusBox.setSelectedItem(tableModel.getValueAt(row, 4).toString());
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();

        searchField = new JTextField(15);
        JButton searchButton = new JButton("Search");
        JButton viewAllButton = new JButton("View All");

        sortBox = new JComboBox<>(new String[]{"Title", "Author", "Year"});
        JButton sortButton = new JButton("Sort");

        filterBox = new JComboBox<>(new String[]{"All", "Not Started", "Reading", "Completed"});

        JButton deleteButton = new JButton("Delete Selected");
        JButton saveButton = new JButton("Save");
        JButton loadButton = new JButton("Load");

        countLabel = new JLabel("Total Papers: 0");

        bottomPanel.add(new JLabel("Search:"));
        bottomPanel.add(searchField);
        bottomPanel.add(searchButton);
        bottomPanel.add(viewAllButton);
        bottomPanel.add(new JLabel("Sort by:"));
        bottomPanel.add(sortBox);
        bottomPanel.add(sortButton);
        bottomPanel.add(new JLabel("Filter:"));
        bottomPanel.add(filterBox);
        bottomPanel.add(deleteButton);
        bottomPanel.add(saveButton);
        bottomPanel.add(loadButton);
        bottomPanel.add(countLabel);

        add(bottomPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> addPaper());
        updateButton.addActionListener(e -> updateSelectedPaper());
        clearButton.addActionListener(e -> clearFields());
        searchButton.addActionListener(e -> searchPaper());
        viewAllButton.addActionListener(e -> refreshTable());
        sortButton.addActionListener(e -> sortPapers());
        filterBox.addActionListener(e -> filterByStatus());
        deleteButton.addActionListener(e -> deleteSelectedPaper());
        saveButton.addActionListener(e -> savePapers());
        loadButton.addActionListener(e -> loadPapers());

        loadSampleData();
        refreshTable();
    }

    private void addPaper() {
        try {
            String title = titleField.getText().trim();
            String author = authorField.getText().trim();
            int year = Integer.parseInt(yearField.getText().trim());
            String topic = topicField.getText().trim();
            String status = statusBox.getSelectedItem().toString();

            if (title.isEmpty() || author.isEmpty() || topic.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.");
                return;
            }

            manager.addPaper(new ResearchPaper(title, author, year, topic, status));
            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Paper added successfully.");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Year must be a valid number.");
        }
    }

    private void updateSelectedPaper() {
        int row = table.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a paper to update.");
            return;
        }

        try {
            String oldTitle = tableModel.getValueAt(row, 0).toString();

            String title = titleField.getText().trim();
            String author = authorField.getText().trim();
            int year = Integer.parseInt(yearField.getText().trim());
            String topic = topicField.getText().trim();
            String status = statusBox.getSelectedItem().toString();

            if (title.isEmpty() || author.isEmpty() || topic.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.");
                return;
            }

            manager.deletePaperByTitle(oldTitle);
            manager.addPaper(new ResearchPaper(title, author, year, topic, status));

            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Paper updated successfully.");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Year must be a valid number.");
        }
    }

    private void searchPaper() {
        String keyword = searchField.getText().trim();

        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter search keyword.");
            return;
        }

        tableModel.setRowCount(0);

        for (ResearchPaper paper : manager.search(keyword)) {
            addPaperToTable(paper);
        }

        updateCountLabel();
    }

    private void sortPapers() {
        String option = sortBox.getSelectedItem().toString();

        if (option.equals("Title")) {
            manager.sortByTitle();
        } 
        else if (option.equals("Author")) {
            manager.sortByAuthor();
        } 
        else if (option.equals("Year")) {
            manager.sortByYear();
        }

        refreshTable();

        JOptionPane.showMessageDialog(
                this,
                "Papers sorted by " + option + "."
        );
    }
    private void filterByStatus() {
        String status = filterBox.getSelectedItem().toString();

        tableModel.setRowCount(0);

        for (ResearchPaper paper : manager.getAllPapers()) {
            if (status.equals("All") || paper.getStatus().equals(status)) {
                addPaperToTable(paper);
            }
        }

        updateCountLabel();
    }

    private void deleteSelectedPaper() {
        int row = table.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a paper to delete.");
            return;
        }

        String title = tableModel.getValueAt(row, 0).toString();
        manager.deletePaperByTitle(title);

        refreshTable();
        clearFields();
        JOptionPane.showMessageDialog(this, "Paper deleted successfully.");
    }

    private void savePapers() {
        try {
            File folder = new File("data");
            if (!folder.exists()) {
                folder.mkdir();
            }

            PrintWriter writer = new PrintWriter(new FileWriter("data/papers.csv", false));

            for (ResearchPaper paper : manager.getAllPapers()) {
                writer.println(
                        paper.getTitle() + "," +
                        paper.getAuthor() + "," +
                        paper.getYear() + "," +
                        paper.getTopic() + "," +
                        paper.getStatus()
                );
            }

            writer.close();
            JOptionPane.showMessageDialog(this, "Papers saved successfully.");

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving papers.");
        }
    }

    private void loadPapers() {
        try {
            File file = new File("data/papers.csv");

            if (!file.exists()) {
                JOptionPane.showMessageDialog(this, "No saved file found.");
                return;
            }

            manager.getAllPapers().clear();
            tableModel.setRowCount(0);

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                if (parts.length == 5) {
                    manager.addPaper(new ResearchPaper(
                            parts[0],
                            parts[1],
                            Integer.parseInt(parts[2]),
                            parts[3],
                            parts[4]
                    ));
                }
            }

            reader.close();
            refreshTable();
            JOptionPane.showMessageDialog(this, "Papers loaded successfully.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading papers.");
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);

        for (ResearchPaper paper : manager.getAllPapers()) {
            addPaperToTable(paper);
        }

        updateCountLabel();
    }

    private void addPaperToTable(ResearchPaper paper) {
        tableModel.addRow(new Object[]{
                paper.getTitle(),
                paper.getAuthor(),
                paper.getYear(),
                paper.getTopic(),
                paper.getStatus()
        });
    }

    private void updateCountLabel() {
        countLabel.setText("Total Papers: " + tableModel.getRowCount());
    }

    private void clearFields() {
        titleField.setText("");
        authorField.setText("");
        yearField.setText("");
        topicField.setText("");
        statusBox.setSelectedIndex(0);
        table.clearSelection();
    }

    private void loadSampleData() {
        if (manager.getAllPapers().isEmpty()) {
            manager.addPaper(new ResearchPaper("Artificial Intelligence in Healthcare", "John Smith", 2023, "Artificial Intelligence", "Reading"));
            manager.addPaper(new ResearchPaper("Cybersecurity Risk Management", "Emily Brown", 2022, "Cybersecurity", "Completed"));
            manager.addPaper(new ResearchPaper("Machine Learning for Education", "David Lee", 2024, "Machine Learning", "Not Started"));
        }
    }
}