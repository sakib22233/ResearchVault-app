import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ResearchVaultTBI {
    private PaperManager manager;
    private Scanner scanner = new Scanner(System.in);
    private static final String FILE_NAME = "data/papers.csv";

    public ResearchVaultTBI(PaperManager manager) { this.manager = manager; }

    public void start() {
        try { manager.loadFromFile(FILE_NAME); } catch (IOException ignored) {}
        int choice;
        do {
            System.out.println("\n===== ResearchVault Text-Based Interface =====");
            System.out.println("1. Add Paper");
            System.out.println("2. View All Papers");
            System.out.println("3. Search Paper");
            System.out.println("4. Sort Papers");
            System.out.println("5. Delete Paper");
            System.out.println("6. Save Papers");
            System.out.println("7. Load Papers");
            System.out.println("8. Exit");
            System.out.print("Choose option: ");
            choice = readInt();
            switch (choice) {
                case 1: addPaper(); break;
                case 2: display(manager.getAllPapers()); break;
                case 3: searchPaper(); break;
                case 4: sortPapers(); break;
                case 5: deletePaper(); break;
                case 6: save(); break;
                case 7: load(); break;
                case 8: System.out.println("Goodbye!"); break;
                default: System.out.println("Invalid option.");
            }
        } while (choice != 8);
    }

    private void addPaper() {
        System.out.print("Title: "); String title = scanner.nextLine();
        System.out.print("Author: "); String author = scanner.nextLine();
        System.out.print("Year: "); int year = readInt();
        System.out.print("Topic: "); String topic = scanner.nextLine();
        System.out.print("Status (Not Started/Reading/Completed): "); String status = scanner.nextLine();
        manager.addPaper(new ResearchPaper(title, author, year, topic, status));
        System.out.println("Paper added successfully.");
    }

    private void searchPaper() {
        System.out.print("Enter keyword: ");
        display(manager.search(scanner.nextLine()));
    }

    private void sortPapers() {
        System.out.println("1. Sort by Title");
        System.out.println("2. Sort by Author");
        System.out.println("3. Sort by Year");
        System.out.print("Choose: ");
        int option = readInt();
        if (option == 1) manager.sortByTitle();
        else if (option == 2) manager.sortByAuthor();
        else if (option == 3) manager.sortByYear();
        else System.out.println("Invalid sort option.");
        display(manager.getAllPapers());
    }

    private void deletePaper() {
        System.out.print("Enter exact title to delete: ");
        boolean deleted = manager.deletePaperByTitle(scanner.nextLine());
        System.out.println(deleted ? "Paper deleted." : "Paper not found.");
    }

    private void save() {
        try { manager.saveToFile(FILE_NAME); System.out.println("Saved successfully."); }
        catch (IOException e) { System.out.println("Save error: " + e.getMessage()); }
    }

    private void load() {
        try { manager.loadFromFile(FILE_NAME); System.out.println("Loaded successfully."); }
        catch (IOException e) { System.out.println("Load error: " + e.getMessage()); }
    }

    private void display(ArrayList<ResearchPaper> papers) {
        if (papers.isEmpty()) { System.out.println("No papers found."); return; }
        for (ResearchPaper p : papers) System.out.println(p);
    }

    private int readInt() {
        while (true) {
            try { return Integer.parseInt(scanner.nextLine()); }
            catch (NumberFormatException e) { System.out.print("Enter a valid number: "); }
        }
    }
}
