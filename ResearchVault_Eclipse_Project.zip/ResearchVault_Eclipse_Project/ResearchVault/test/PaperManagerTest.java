import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PaperManagerTest {
    @Test
    public void testAddPaper() {
        PaperManager manager = new PaperManager();
        manager.addPaper(new ResearchPaper("AI Ethics", "Smith", 2023, "AI", "Reading"));
        assertEquals(1, manager.getAllPapers().size());
    }

    @Test
    public void testSearchPaper() {
        PaperManager manager = new PaperManager();
        manager.addPaper(new ResearchPaper("Cyber Security Trends", "Jones", 2022, "Cybersecurity", "Completed"));
        assertEquals(1, manager.search("Cyber").size());
    }

    @Test
    public void testDeletePaper() {
        PaperManager manager = new PaperManager();
        manager.addPaper(new ResearchPaper("Data Mining", "Brown", 2021, "Data Science", "Not Started"));
        assertTrue(manager.deletePaperByTitle("Data Mining"));
        assertEquals(0, manager.getAllPapers().size());
    }
}
